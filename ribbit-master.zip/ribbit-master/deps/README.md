```json
{
    "markdown-it": "8.4.1",
    "noty": "3.1.4",
    "prism": "1.14.0"
}
```
// Design not done.

export interface BlockSchema {
  blockNumber: number;
  fullySynced: boolean;
  _id: string;
}
